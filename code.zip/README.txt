Not much to see here:

ner.py (our model)

gazetter.py (how we got the Mexican cities list)

comparisons.py (a list of results, labeled. Please read writeup for more info.)

features_list.py (literally just the features)

wrongs.py (a way to further analyze which words were misclassified)